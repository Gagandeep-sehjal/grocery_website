-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2021 at 11:20 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `superstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `h_id` int(50) NOT NULL,
  `NAME` varchar(50) NOT NULL,
  `USERNAME` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `price`) VALUES
(1, 'IPhone 6s', 40000),
(2, 'IPhone 7', 60000),
(3, 'IPhone 7 Plus', 69000),
(4, 'IPhone X', 88000),
(5, 'Samsung Galaxy S7 EDGE', 45000),
(6, 'Samsung Galaxy S8 PLUS', 65000),
(7, 'Samsung Galaxy NOTE 8 PLUS', 60000),
(8, 'Samsung Galaxy A8 ', 35000),
(9, 'ONEPLUS 3', 28000),
(10, 'ONEPLUS 3T', 31000),
(11, 'ONEPLUS 5', 34000),
(12, 'ONEPLUS 5T', 36000),
(13, 'XIAOMI REDMI NOTE 4', 13000),
(14, 'MI A1', 15000),
(15, 'MI MAX 2', 16000),
(16, 'MI MIX 2', 36000);

-- --------------------------------------------------------

--
-- Table structure for table `tblautonumber`
--

CREATE TABLE `tblautonumber` (
  `id` int(11) NOT NULL,
  `start` int(11) NOT NULL,
  `end` int(11) NOT NULL,
  `increment` int(11) NOT NULL,
  `desc` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblautonumber`
--

INSERT INTO `tblautonumber` (`id`, `start`, `end`, `increment`, `desc`) VALUES
(1, 1000, 17, 1, 'PROD');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `category_id` int(11) NOT NULL,
  `category` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`category_id`, `category`) VALUES
(1, 'for sugarcane'),
(2, 'for rice'),
(3, 'for vegetable');

-- --------------------------------------------------------

--
-- Table structure for table `tblemployee`
--

CREATE TABLE `tblemployee` (
  `emp_id` int(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `gender` varchar(50) NOT NULL,
  `age` int(2) NOT NULL,
  `position` varchar(50) NOT NULL,
  `hire_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblemployee`
--

INSERT INTO `tblemployee` (`emp_id`, `fname`, `lname`, `contact`, `email`, `address`, `gender`, `age`, `position`, `hire_date`) VALUES
(1, 'Caren', 'Bautista', '09098591074', 'caren@yahoo.com', 'Kabankalan', 'Female', 23, 'Manager', '2019-11-30'),
(2, 'Jahzel', 'Alarcon', '09509827365', 'jahiam07@gmail.com', 'Isabela', 'Female', 22, 'Manager', '2019-12-01'),
(3, 'Ryan', 'Mana-ay', '09786534342', 'Ryan@yahoo.com', 'Himamaylan ', 'Male', 21, 'Supervisor', '2019-12-02');

-- --------------------------------------------------------

--
-- Table structure for table `tblinventory`
--

CREATE TABLE `tblinventory` (
  `transac_id` int(50) NOT NULL,
  `product_id` int(50) NOT NULL,
  `quantity` int(50) NOT NULL,
  `date_in` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblproducts`
--

CREATE TABLE `tblproducts` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `price` int(20) NOT NULL,
  `profit` int(22) NOT NULL,
  `date_in` varchar(50) NOT NULL,
  `category_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_code` varchar(11) NOT NULL,
  `status` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblproducts`
--

INSERT INTO `tblproducts` (`product_id`, `product_name`, `quantity`, `price`, `profit`, `date_in`, `category_id`, `supplier_id`, `user_id`, `product_code`, `status`) VALUES
(1, 'Amigo(14-14-14)', 100339, 1800, 20000, '2019-11-21', 1, 2, 1, '1009', 'Available'),
(2, 'Amigo(21-0-0-24)', 33, 1500, 1800, '2019-11-21', 2, 2, 1, '1010', 'Available'),
(3, 'Atlas(2100)', 15, 1500, 1800, '2019-11-21', 1, 3, 1, '1011', 'Available'),
(4, 'Harvester(14-14-11s)', 10, 1800, 2000, '2019-11-21', 1, 1, 1, '1012', 'Available'),
(5, 'Harvester(16-20)', 50, 1300, 1500, '2019-11-21', 1, 1, 1, '1013', 'Available'),
(6, 'Amigo(14-14-14)', 99, 1000, 1300, '2019-11-21', 3, 2, 1, '1014', 'Available'),
(7, 'Amigo(14-14-14)', 12, 125, 5, '2019-11-22', 2, 2, 2, '1015', 'Available'),
(8, '	Amigo(14-14-14)', 45, 45, 5555, '2019-11-28', 1, 1, 2, '1016', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `tblsupplier`
--

CREATE TABLE `tblsupplier` (
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(30) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `email` varchar(20) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsupplier`
--

INSERT INTO `tblsupplier` (`supplier_id`, `supplier_name`, `contact`, `email`, `address`) VALUES
(1, 'gagandeep', '9095643236', '19bcs2810@gmail.com', 'indore,MP'),
(2, 'Amigo', '9786534213', 'Amigo@yahoo.com', 'Bgry.Singkang Bacolod City'),
(3, 'Atlas', '9096547321', 'Atlas@yahoo.com', 'Brgy.Poblacion, Bacolod City');

-- --------------------------------------------------------

--
-- Table structure for table `tbltransac`
--

CREATE TABLE `tbltransac` (
  `transac_id` int(11) NOT NULL,
  `transac_code` int(100) NOT NULL,
  `date` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_code` varchar(200) NOT NULL,
  `qty` int(20) NOT NULL,
  `price` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltransac`
--

INSERT INTO `tbltransac` (`transac_id`, `transac_code`, `date`, `customer_id`, `product_code`, `qty`, `price`, `total`) VALUES
(31, 1554235838, '2019-04-03', 39, '100', 1, 350, 350),
(32, 1554235838, '2019-04-03', 39, '1002', 1, 400, 400),
(33, 1554251111, '2019-04-03', 39, '100', 1, 350, 350),
(34, 1572074522, '2019-10-26', 42, '1001', 5, 400, 2000),
(35, 1572074522, '2019-10-26', 42, '100', 3, 350, 1050),
(36, 1572075891, '2019-10-26', 42, '1003', 20, 300, 6000),
(37, 1572356267, '2019-10-29', 42, '1001', 3, 400, 1200),
(38, 1572356267, '2019-10-29', 42, '1005', 16, 300, 4800),
(39, 1572850714, '2019-11-04', 42, '100', 1, 1500, 1500),
(40, 1572850714, '2019-11-04', 42, '1001', 1, 1500, 1500),
(41, 1573016058, '2019-11-06', 42, '100', 15, 1500, 22500),
(42, 1573057409, '2019-11-07', 46, '1001', 7, 1500, 10500),
(43, 1573110712, '2019-11-07', 46, '1001', 1, 1500, 1500),
(44, 1573788177, '2019-11-15', 46, '1001', 1, 1500, 1500),
(45, 1573788177, '2019-11-15', 46, '1002', 1, 1500, 1500),
(46, 1573993061, '2019-11-17', 0, '1004', 1, 1000, 1000),
(47, 1573993148, '2019-11-17', 30, '1004', 1, 1000, 1000),
(48, 1573993179, '2019-11-17', 30, '1004', 1, 1000, 1000),
(49, 1573993307, '2019-11-17', 30, '1004', 1, 1000, 1000),
(50, 1573993636, '2019-11-17', 30, '1004', 2, 1000, 2000),
(51, 1574060123, '2019-11-18', 30, '1004', 10, 1000, 10000),
(52, 1574302308, '2019-11-21', 2, '1010', 1, 1500, 1500),
(53, 1574306845, '2019-11-21', 2, '1010', 1, 1500, 1500),
(54, 1574306845, '2019-11-21', 2, '1009', 1, 1800, 1800),
(55, 1574329865, '2019-11-21', 3, '1009', 1, 1800, 1800),
(56, 1574330004, '2019-11-21', 3, '1011', 1, 1500, 1500),
(57, 1574331170, '2019-11-21', 4, '1010', 1, 1500, 1500),
(58, 1574408390, '2019-11-22', 2, '1009', 6, 1800, 10800),
(59, 1574408390, '2019-11-22', 2, '1010', 20, 1500, 30000),
(60, 1574408390, '2019-11-22', 2, '1011', 20, 1500, 30000),
(61, 1574408390, '2019-11-22', 2, '1014', 20, 1000, 20000),
(62, 1574408442, '2019-11-22', 2, '1014', 20, 1000, 20000),
(63, 1574602908, '2019-11-24', 1, '1014', 1, 1000, 1000),
(64, 1574732852, '2019-11-26', 1, '1009', 1, 1800, 1800),
(65, 1574836996, '2019-11-27', 1, '1009', 1, 1800, 1800),
(66, 1574841234, '2019-11-27', 1, '1009', 1, 1800, 1800),
(67, 1574841234, '2019-11-27', 1, '1014', 20, 1000, 20000),
(68, 1574844266, '2019-11-27', 1, '1010', 1, 1500, 1500),
(69, 1574872971, '2019-11-28', 1, '1011', 5, 1500, 7500),
(70, 1574872971, '2019-11-28', 1, '1010', 50, 1500, 75000),
(71, 1575428004, '2019-12-04', 1, '1010', 25, 1500, 37500),
(72, 1575428004, '2019-12-04', 1, '1011', 40, 1500, 60000),
(73, 1575428113, '2019-12-04', 2, '1010', 30, 1500, 45000),
(74, 1575428113, '2019-12-04', 2, '1011', 30, 1500, 45000),
(75, 1575428238, '2019-12-04', 3, '1012', 45, 1800, 81000),
(76, 1575428238, '2019-12-04', 3, '1010', 40, 1500, 60000),
(77, 1575872572, '2019-12-09', 1, '1011', 14, 1500, 21000),
(78, 1575873091, '2019-12-09', 1, '1011', 15, 1500, 22500),
(79, 1576051349, '2019-12-11', 1, '1010', 1, 1500, 1500),
(80, 1576051349, '2019-12-11', 1, '1014', 1, 1000, 1000),
(81, 1576051349, '2019-12-11', 1, '1012', 5, 1800, 9000);

-- --------------------------------------------------------

--
-- Table structure for table `tbltransacdetail`
--

CREATE TABLE `tbltransacdetail` (
  `detail_id` int(11) NOT NULL,
  `transac_code` int(11) NOT NULL,
  `date` datetime(6) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `deliveryfee` int(11) NOT NULL,
  `pay_met` varchar(30) NOT NULL,
  `totalprice` int(11) NOT NULL,
  `status` varchar(200) NOT NULL,
  `remarks` text NOT NULL,
  `delivery_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltransacdetail`
--

INSERT INTO `tbltransacdetail` (`detail_id`, `transac_code`, `date`, `customer_id`, `deliveryfee`, `pay_met`, `totalprice`, `status`, `remarks`, `delivery_date`) VALUES
(1, 1575428004, '2019-12-04 00:00:00.000000', 1, 150, '', 97650, 'Cancelled', 'Your order has been cancelled <br>\r\n	 due to lack of communication <br> and incomplete informatio!', '2019-12-10 00:00:00.000000'),
(2, 1575428113, '2019-12-04 00:00:00.000000', 2, 150, '', 90150, 'Confirmed', 'Your order has been confirmed!', '2019-12-16 00:00:00.000000'),
(3, 1575428238, '2019-12-04 00:00:00.000000', 3, 150, '', 141150, 'Confirmed', 'Your order has been confirmed!', '2019-12-20 00:00:00.000000'),
(4, 1575872572, '2019-12-09 00:00:00.000000', 1, 150, '', 21150, 'Pending', '', '2019-12-10 00:00:00.000000'),
(5, 1575873091, '2019-12-09 00:00:00.000000', 1, 150, '', 22650, 'Pending', '', '2019-12-10 00:00:00.000000'),
(6, 1576051349, '2019-12-11 00:00:00.000000', 1, 150, '', 11650, 'Pending', '', '2019-06-20 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `user_id` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact` int(11) NOT NULL,
  `address` text NOT NULL,
  `position` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `pass` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`user_id`, `fname`, `lname`, `email`, `contact`, `address`, `position`, `username`, `pass`) VALUES
(2, 'Gagandeep', 'Singh Sehjal', 'caren@yahoo.com', 0, '', 'Admin', 'admin', '$2y$10$ds1gqSSjIHq/I7c.Ly/w9eF.OPgcXyeG09wL71loBGy0qLkNzUZlS'),
(4, 'Ankit', 'Thakur', '19bcs28XX@gmail.com', 0, '', 'Admin', 'admin1', '$2y$10$/oaULYaxbdRS5aOMSkzQoOEIsl/Ben85S/KYkMober4WNUWUecqQO');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `contact`, `city`, `address`) VALUES
(4, 'Gagandeep sehjal', '19bcs2810@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '9818821812', 'Indore', 'indore,MP');

-- --------------------------------------------------------

--
-- Table structure for table `users_items`
--

CREATE TABLE `users_items` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `status` enum('Added to cart','Confirmed') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`h_id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblautonumber`
--
ALTER TABLE `tblautonumber`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `tblemployee`
--
ALTER TABLE `tblemployee`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `tblproducts`
--
ALTER TABLE `tblproducts`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `FK_tblproducts_tblsupplier` (`supplier_id`,`user_id`);

--
-- Indexes for table `tblsupplier`
--
ALTER TABLE `tblsupplier`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Indexes for table `tbltransac`
--
ALTER TABLE `tbltransac`
  ADD PRIMARY KEY (`transac_id`),
  ADD KEY `FK_tbltransac_details_tblcustomer` (`customer_id`);

--
-- Indexes for table `tbltransacdetail`
--
ALTER TABLE `tbltransacdetail`
  ADD PRIMARY KEY (`detail_id`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_items`
--
ALTER TABLE `users_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `item_id` (`item_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `h_id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tblautonumber`
--
ALTER TABLE `tblautonumber`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblemployee`
--
ALTER TABLE `tblemployee`
  MODIFY `emp_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblproducts`
--
ALTER TABLE `tblproducts`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tblsupplier`
--
ALTER TABLE `tblsupplier`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbltransac`
--
ALTER TABLE `tbltransac`
  MODIFY `transac_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `tbltransacdetail`
--
ALTER TABLE `tbltransacdetail`
  MODIFY `detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users_items`
--
ALTER TABLE `users_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `users_items`
--
ALTER TABLE `users_items`
  ADD CONSTRAINT `users_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`),
  ADD CONSTRAINT `users_items_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
