<?php
 $db = mysqli_connect('localhost', 'your_username','your_password') or
        die ('Unable to connect. Check your connection parameters.');
        mysqli_select_db($db, 'superstore' ) or die(mysqli_error($db));
?>